//
//  UserViewController.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-08-01.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit

class UserViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var password: UITextField!
    var x:String!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var confirm: UITextField!
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var name: UITextField!
    
    

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let getInfo = DatabaseHelper.instance.getAllInfo()
        name.text = (getInfo.2)
        address.text = (getInfo.3)
        imageView.image = UIImage(data: getInfo.4!)
        email.text = getInfo.0
        password.text = getInfo.1
        
        print(getInfo.4);
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        
        imageView.isUserInteractionEnabled = true
         imageView.addGestureRecognizer(tapGestureRecognizer)
                
        // Do any additional setup after loading the view.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    
    
    @IBAction func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
       {
    let pickerController = UIImagePickerController()
           pickerController.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
           pickerController.allowsEditing = true
           
           let alertController = UIAlertController(title: "Add Image", message: "Choose", preferredStyle: .actionSheet)
           /*
           let cameraAction = UIAlertAction(title: "Camera", style: .default) { (action) in
               pickerController.sourceType = .camera
               self.present(pickerController, animated: true, completion: nil)
               
           }
    */
           
           let photosLibraryAction = UIAlertAction(title: "Gallery", style: .default) { (action) in
               pickerController.sourceType = .photoLibrary
               self.present(pickerController, animated: true, completion: nil)
               
           }
           
           
           
           let imagex = UIAlertAction(title: "Camera", style: .default)
                  { (action) in
                      if UIImagePickerController.isSourceTypeAvailable(.camera){
                          let imagePicker = UIImagePickerController()
                          imagePicker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
                          imagePicker.sourceType = UIImagePickerController.SourceType.camera
                          imagePicker.allowsEditing = false
                          self.present(imagePicker,animated: true, completion: nil)
                      }
                      else{
                          
                          var myAlert = UIAlertController(title: "Alert", message: "Camera Not Available", preferredStyle: UIAlertController.Style.alert);
                          let okAction = UIAlertAction(title: "Ok", style: .destructive ,handler: nil)
                              
                          
                          myAlert.addAction(okAction);
                          self.present(myAlert, animated: true, completion: nil)
                          
                      }
                  }
                     
          /*
           let savedPhotosAction = UIAlertAction(title: "Saved Photos Album", style: .default) { (action) in
               pickerController.sourceType = .savedPhotosAlbum
               self.present(pickerController, animated: true, completion: nil)
               
           }
           */
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
           
           //alertController.addAction(cameraAction)
           alertController.addAction(imagex)
           alertController.addAction(photosLibraryAction)
         //  alertController.addAction(savedPhotosAction)
           alertController.addAction(cancelAction)
           
           present(alertController, animated: true, completion: nil)
           
       }
       
       func imagePickerController(_ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
            {
           self.dismiss(animated: true, completion: nil)
           
           if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
               imageView.image = image
                //picker.dismiss(animated: true, completion: nil)
           }
       }
       
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
           
       }
    
    
    
    
    @IBAction func savechanges(_ sender: Any) {
           
           
           let getemail = email.text;
           let getpassword = password.text;
           let username = name.text;
           let location = address.text;
           x = phone.text
           let mobile = Int(x)
        let png = self.imageView.image!.pngData()
           
           
        print(png!); if(getemail!.isEmpty||getpassword!.isEmpty||username!.isEmpty||location!.isEmpty||x!.isEmpty)
                   {
                       displayAlertMessages(userMessages: "All Fields Are Required");
                       return;
           
                   }
           
           DatabaseHelper.instance.userdetail(at: png!, at: getemail!, at: getpassword!, at: location!, at: username!, at : mobile!)
           
           self.dismiss(animated: true, completion: nil)
           
       }
       
       func displayAlertMessages(userMessages:String){
              var myAlert = UIAlertController(title: "Alert", message: userMessages, preferredStyle: UIAlertController.Style.alert);
              
              let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil);
              
              myAlert.addAction(okAction);
              self.present(myAlert, animated: true, completion: nil)
          }

}
