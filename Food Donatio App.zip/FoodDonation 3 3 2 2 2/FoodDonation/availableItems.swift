//
//  availableItems.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-08-07.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import NotificationBannerSwift

class availableItems: UIViewController {
    
    var y :Float!
    var x : Int64!
    var z : Date!
    var s :String!
    var vcaddress : String!
     var vcname : String!
     var vcphone : Int64!
    
     typealias ImageArray = [UIImage]
    @IBOutlet weak var time: UITextField!
    
    @IBOutlet weak var type: UITextField!
    
    
    @IBOutlet weak var category: UITextField!
    
    @IBOutlet weak var imageview: UIImageView!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var comments: UILabel!
    
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var phone: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
            //(username , address , kind , cat,comment,date,amount,phone) ;
        
        vcname = UserDefaults.standard.string(forKey: "name")
        vcaddress = UserDefaults.standard.string(forKey: "home")
        vcphone = Int64(UserDefaults.standard.integer(forKey: "mobile"))
        
        print(vcname ?? "null value hai");
        print(vcaddress ?? "null value hai");
        print(vcphone ?? "null value hai pc");
        
        
        
        let donation = DatabaseHelper.instance.getAllDonation()
        if(donation.0!.isEmpty||donation.2!.isEmpty||donation.4!.isEmpty||donation.3!.isEmpty||donation.6!==nil||donation.8!==nil)
        {
            name.text = "NOT Available"
            type.text = "NOT Available"
            comments.text = "NOT Available"
            category.text = "NOT Available"
            amount.text = "NOT Available"
            phone.text = "NOT Available"
           
        }
        
        name.text = donation.0
        type.text = donation.2
        comments.text = donation.4
        category.text = donation.3
        y = (donation.6)
        amount.text = String(y)
        x = donation.8
        phone.text = String(x)
        z = (donation.5!)
        
        
        let formatter = DateFormatter()
        // initially set the format based on your datepicker date / server String
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

        let myString = formatter.string(from: z) // string purpose I add here
        // convert your string to date
        let yourDate = formatter.date(from: myString)
        //then again set the date format whhich type of output you need
        formatter.dateFormat = "dd-MMM-yyyy HH:mm:ss"
        // again convert your date to string
        let myStringafd = formatter.string(from: yourDate!)
        time.text = myStringafd
        print(myStringafd)
        
        self.imageview.animationImages = self.imageArray()
                   self.imageview.animationDuration = 3.0
                   self.imageview.startAnimating()
        
    }
    
    func imageArray() -> ImageArray? {
        let getInfo = DatabaseHelper.instance.getAllDonation()
    if let mySavedData = NSKeyedUnarchiver.unarchiveObject(with: getInfo.7!) as? NSArray {
            // TODO: Use regular map and return nil if something can't be turned into a UIImage
            let imgArray = mySavedData.flatMap({
                return UIImage(data: $0 as! Data)
            })
            return imgArray
        }
        else {
            print("Unable to convert data to ImageArray")
            return nil
        }
    }
    
        
    @IBAction func back(_ sender: Any) {
         self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func comfimed(_ sender: Any) {
        
                let img = DatabaseHelper.instance.getAllInfo()

        DatabaseHelper.instance.saveavaibleitem(at: img.4!, at: vcaddress, at: vcname, at: vcphone)
        
        if let storyboard = self.storyboard {
                        let newViewController = storyboard.instantiateViewController(withIdentifier: "slidemenu")
        self.present(newViewController, animated: true, completion: nil)
                    }
        
        let banner = NotificationBanner(title: "Your Donation has been Requested ", subtitle:"Thank You for Donation" , leftView: nil, rightView: nil, style: .info, colors: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 10 , execute: {
            banner.show()
        })
        
    }
    
    
    
}
