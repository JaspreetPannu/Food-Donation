//
//  LocationViewController.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-08-07.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import MapKit


class LocationViewController: UIViewController, MKMapViewDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet var getDirection: UIButton!
    @IBOutlet var searchAddress: UITextField!
    
    
    let locationManager = CLLocationManager()
    let regionInMeters: Double = 100000
    
    
    
    //43.727126, -79.242956 vaibhav
    //43.720486, -79.616356 pannu
    //43.733469, -79.608897 sid
    
//toronto
//  43.792288, -79.344447
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        checkLocationServices()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        mapView.delegate = self
        
//        let annontation = MKPointAnnotation()
//        annontation.coordinate = CLLocationCoordinate2D(latitude: 43.727126, longitude: -79.242956)
//        annontation.title = "Vaibhav Dutt"
//        annontation.subtitle = "abc"
//        mapView.addAnnotation(annontation)
//
//
//        let region = MKCoordinateRegion(center: annontation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
//        mapView.setRegion(region,animated: true)
//
//       mapsvalue(longitude: 43.727126, latitude:  -79.242956)
//
//        mapsvalue(longitude: 43.720486, latitude: -79.616356)
//    }
        createAnnotation(locations: annotationLocations)
    }
    
    
    @IBAction func getDirectionTapped(_ sender: Any) {
        getAddress()
    }
    
    func getAddress() {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(searchAddress.text!) { (placemarks, error) in
            guard let placemarks = placemarks, let location = placemarks.first?.location
                else {
                    print("No Location Found")
                    return
            }
            print(location)
            self.mapThis(destinationCord: location.coordinate)
        }
    }
    
    
    func mapThis(destinationCord : CLLocationCoordinate2D) {
        let souceCordinate = (locationManager.location?.coordinate)!
        
        let soucePlaceMark = MKPlacemark(coordinate: souceCordinate)
        let destPlacemark = MKPlacemark(coordinate: destinationCord)
        
        let sourceItem = MKMapItem(placemark: soucePlaceMark)
        let destItem = MKMapItem(placemark: destPlacemark)
        
        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destItem
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true
        
        let directions = MKDirections(request: destinationRequest)
        directions.calculate { (response, error) in
            guard let response = response else {
                if let error = error {
                    print("Something is wrong :(")
                }
                return
            }
            
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline)
            self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendereFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolygonRenderer(overlay: overlay as! MKPolyline)
        render.strokeColor = .blue
        return render
    }
    
    
    
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func centerViewOnUserLocation() {
        if let location = locationManager.location?.coordinate {
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: regionInMeters, longitudinalMeters: regionInMeters)
            mapView.setRegion(region, animated: true)
        }
    }
    
    
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationManager()
            checkLocationAuthorization()
        }
        else {
            print("location services are disables")
        }
    }
    
    
    func checkLocationAuthorization() {
        switch CLLocationManager.authorizationStatus() {
         case .authorizedWhenInUse:
                  mapView.showsUserLocation = true
                  centerViewOnUserLocation()
                  locationManager.startUpdatingLocation()
                  break
        case .denied:
            break
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            break
        case .authorizedAlways:
            break
    }
}
    
    
    
    let annotationLocations = [
        
        ["title":"Donation Center", "latitude": 43.727126, "longitude": -79.242956],
        ["title":"Donation Center", "latitude": 43.720486, "longitude": -79.616356],
        ["title":"Donation Center", "latitude": 43.733469, "longitude": -79.608897]
        
    ]
    
    func createAnnotation(locations : [[String : Any]])  {
        
        
        for location in locations{
            let annotations = MKPointAnnotation()
            annotations.title = location["title"] as? String
            
            print(location["latitude"]!)
            annotations.coordinate = CLLocationCoordinate2D(latitude: location["latitude"] as! CLLocationDegrees, longitude: location["longitude"] as! CLLocationDegrees)
            mapView.addAnnotation(annotations)
            let region = MKCoordinateRegion(center: annotations.coordinate, latitudinalMeters: 100000, longitudinalMeters: 100000)
                        mapView.setRegion(region,animated: true)
        }
        
       
    }
    
    
    
    func mapsvalue(longitude: double_t,latitude : double_t) -> Void {
         let annontation = MKPointAnnotation()
        
       annontation.coordinate = CLLocationCoordinate2D(latitude: 43.727126, longitude: -79.242956)
        annontation.title = "Donation Center"
        annontation.subtitle = "16 Oakridge Drive, Scarbourough"
        mapView.addAnnotation(annontation)
        
        
        annontation.coordinate = CLLocationCoordinate2D(latitude: 43.720486, longitude: -79.616356)
               annontation.title = "Donation Center"
               annontation.subtitle = "69 Cinrickbar Drive, Etobicoke"
               mapView.addAnnotation(annontation)
        
        
        annontation.coordinate = CLLocationCoordinate2D(latitude: 43.733469, longitude: -79.608897)
               annontation.title = "Donation Center"
               annontation.subtitle = "32 Autumn Glen Circle, Etobicoke"
               mapView.addAnnotation(annontation)
        
        
        let region = MKCoordinateRegion(center: annontation.coordinate, latitudinalMeters: 100000, longitudinalMeters: 100000)
        mapView.setRegion(region,animated: true)
        
    }
}

extension LocationViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation] ) {
        guard let location = locations.last else { return }
        let region = MKCoordinateRegion.init(center: location.coordinate, latitudinalMeters: regionInMeters, longitudinalMeters: regionInMeters)
        mapView.setRegion(region, animated: true)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
         checkLocationAuthorization()
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
             
             textField.resignFirstResponder()
             return true
         }
}
