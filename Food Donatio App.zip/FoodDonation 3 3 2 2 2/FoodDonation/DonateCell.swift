//
//  DonateCell.swift
//  FoodDonation
//
//  Created by Sidharth Mehta on 08/08/20.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit

class DonateCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var fname: UILabel!
    
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var date: UILabel!
    
    

    
    
    
}
