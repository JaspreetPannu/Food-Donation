//
//  DonateFoodViewController.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-07-27.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import Photos
import BSImagePicker

class DonateFoodViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    
    
    @IBOutlet weak var imageview: UIImageView!
    var SelectedAssests = [PHAsset]()
    var PhotoArray = [UIImage]()
    
    
    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var mobile: UITextField!
    
    @IBOutlet weak var Address: UITextField!
    
    
    @IBOutlet weak var Amount: UITextField!
    
    
    @IBOutlet weak var comments: UITextField!
    
    @IBOutlet weak var type: UISegmentedControl!
    
    
    @IBOutlet weak var cat: UISegmentedControl!
    
    @IBOutlet weak var datepicker: UIDatePicker!
    override func viewDidLoad() {
        
        super.viewDidLoad()
//
    let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
   imageview.isUserInteractionEnabled = true
    imageview.addGestureRecognizer(tapGestureRecognizer)
            let getInfo = DatabaseHelper.instance.getAllInfo()
                    
        userName.text = (getInfo.2)
        Address.text = (getInfo.3)
                   
      
    }
    
    
    @IBAction func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        SelectedAssests.removeAll()
        PhotoArray.removeAll()
//       let pickerController = UIImagePickerController()
//       pickerController.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
//          pickerController.allowsEditing = true
        
        let alertController = UIAlertController(title: "Add Image", message: "Choose", preferredStyle: .actionSheet)
        
        let photosLibraryAction = UIAlertAction(title: "Gallery", style: .default) { (action) in
                  

               
        
        
             let imagePicker = ImagePickerController()
            self.presentImagePicker(imagePicker, select: { (asset) in
            // User selected an asset. Do something with it. Perhaps begin processing/upload?
        }, deselect: { (asset) in
            // User deselected an asset. Cancel whatever you did when asset was selected.
        }, cancel: { (assets) in
            // User canceled selection.
        }, finish: { (assets : [PHAsset]) in
            // User finished selection assets.
            for i in 0..<assets.count
            {
                self.SelectedAssests.append(assets[i])
            }
            self.convertAssetToImages()
            
            
            
        })
    }
        
        
        let imagex = UIAlertAction(title: "Camera", style: .default)
               { (action) in
                   if UIImagePickerController.isSourceTypeAvailable(.camera)
                   {
                       let imagePicker = UIImagePickerController()
                       imagePicker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
                       imagePicker.sourceType = UIImagePickerController.SourceType.camera
                       imagePicker.allowsEditing = false
                    
                   }
                   else
                   {

                       var myAlert = UIAlertController(title: "Alert", message: "Camera Not Available", preferredStyle: UIAlertController.Style.alert);
                       let okAction = UIAlertAction(title: "Ok", style: .destructive ,handler: nil)


                       myAlert.addAction(okAction);
                       self.present(myAlert, animated: true, completion: nil)

                   }
               }
        

          let cancelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)

          //alertController.addAction(cameraAction)
          alertController.addAction(imagex)
          alertController.addAction(photosLibraryAction)
        //  alertController.addAction(savedPhotosAction)
          alertController.addAction(cancelAction)

          present(alertController, animated: true, completion: nil)

    }
    
    func convertAssetToImages(){
        if SelectedAssests.count != 0
        {
            
            for i in 0..<SelectedAssests.count{
                
                let manager = PHImageManager.default()
                let option = PHImageRequestOptions()
                var thumbnail = UIImage()
                option.isSynchronous = true
                manager.requestImage(for: SelectedAssests[i], targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFit, options: option, resultHandler:{ (result,info)->Void in
                thumbnail = result!
                
            })
                let data = thumbnail.jpegData(compressionQuality: 0.7)
                let newImage = UIImage(data: data!)
                self.PhotoArray.append(newImage! as UIImage)
                
                    
                }
            self.imageview.animationImages = self.PhotoArray
            self.imageview.animationDuration = 3.0
            self.imageview.startAnimating()
        }
    }
    
//let pickerController = UIImagePickerController()
//     pickerController.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
//        pickerController.allowsEditing = true
//
//        let alertController = UIAlertController(title: "Add Image", message: "Choose", preferredStyle: .actionSheet)
//        /*
//        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (action) in
//            pickerController.sourceType = .camera
//            self.present(pickerController, animated: true, completion: nil)
//
//        }
// */
//
//        let photosLibraryAction = UIAlertAction(title: "Gallery", style: .default) { (action) in
//            pickerController.sourceType = .photoLibrary
//            self.present(pickerController, animated: true, completion: nil)
//
//        }
//


//        let imagex = UIAlertAction(title: "Camera", style: .default)
//               { (action) in
//                   if UIImagePickerController.isSourceTypeAvailable(.camera)
//                   {
//                       let imagePicker = UIImagePickerController()
//                       imagePicker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
//                       imagePicker.sourceType = UIImagePickerController.SourceType.camera
//                       imagePicker.allowsEditing = false
//
//                   }
//                   else
//                   {
//
//                       var myAlert = UIAlertController(title: "Alert", message: "Camera Not Available", preferredStyle: UIAlertController.Style.alert);
//                       let okAction = UIAlertAction(title: "Ok", style: .destructive ,handler: nil)
//
//
//                       myAlert.addAction(okAction);
//                       self.present(myAlert, animated: true, completion: nil)
//
//                   }
//               }

       /*
        let savedPhotosAction = UIAlertAction(title: "Saved Photos Album", style: .default) { (action) in
            pickerController.sourceType = .savedPhotosAlbum
            self.present(pickerController, animated: true, completion: nil)

        }
        */
//
//        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
//
//        //alertController.addAction(cameraAction)
//        alertController.addAction(imagex)
//        alertController.addAction(photosLibraryAction)
//      //  alertController.addAction(savedPhotosAction)
//        alertController.addAction(cancelAction)
//
//        present(alertController, animated: true, completion: nil)

 //   }

    func imagePickerController(_ picker: UIImagePickerController,
         didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
         {
        self.dismiss(animated: true, completion: nil)

        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageview.image = image
             //picker.dismiss(animated: true, completion: nil)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)

    }

       func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           
           textField.resignFirstResponder()
           return true
       }

    
    
     //var phone,name,address :String!
    
    
    
    @IBAction func Donate(_ sender: Any) {
        let name = userName.text
                       let Phone = (Int)(mobile.text!)
                       let address = Address.text
                       let amount = (Float)(Amount.text!)
                       let comment = comments.text
                       let kind = type.titleForSegment(at: type.selectedSegmentIndex)
                       let category = cat.titleForSegment(at: cat.selectedSegmentIndex)
                       let dateFormatter = DateFormatter()
                       dateFormatter.dateStyle = DateFormatter.Style.short
                       dateFormatter.timeStyle = DateFormatter.Style.short
                       let strDate = dateFormatter.string(from: datepicker.date)
                      
                       

                       let CDataArray = NSMutableArray();

                       for img in PhotoArray{
                           let data : NSData = NSData(data: img.pngData()!)
                           CDataArray.add(data);
                       }

                       //convert the Array to NSData
                       //you can save this in core data
                       let coreDataObject = NSKeyedArchiver.archivedData(withRootObject: CDataArray);
               //
                      
               if (mobile.text!.isEmpty || address!.isEmpty || Amount.text!.isEmpty || kind!.isEmpty||category!.isEmpty||strDate.isEmpty) {
                    displayAlertMessages(userMessages: "All Fields Are Required");
                              return;
               }
               
               
               DatabaseHelper.instance.saveEntity2(at: coreDataObject, at: comment!, at: amount!, at: address!, at: name!, at: kind!, at: category!, at: Phone!, at: datepicker.date)
                       
        
        
        print(name,Phone,address,amount,comment,kind,category,strDate)
        
    }
    
        
    
    func displayAlertMessages(userMessages:String){
        var myAlert = UIAlertController(title: "Alert", message: userMessages, preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    @IBAction func back(_ sender: Any) {
        print("MAi nhi chalna pc");
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
