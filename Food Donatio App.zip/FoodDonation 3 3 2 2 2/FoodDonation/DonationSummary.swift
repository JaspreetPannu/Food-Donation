//
//  DonationSummary.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-08-10.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import CoreData

class DonationSummary: UIViewController {
    var x : Int64!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    override func viewDidLoad() {
    
        super.viewDidLoad()

        let orderperson = DatabaseHelper.instance.getDonationInfo()
        address.text = orderperson.1
      x = orderperson.2
          phone.text = String(x)
        imgview.image = UIImage(data:orderperson.3!)
        name.text = orderperson.0
        
        
    }
    

    @IBAction func deletedonation(_ sender: Any) {
        
        let context = ( UIApplication.shared.delegate as! AppDelegate ).persistentContainer.viewContext
               let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "DonationInfo")
               let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
               do
               {
                   try context.execute(deleteRequest)
                   try context.save()
                print("hogaya delete bc")
               }
               catch
               {
                   print ("There was an error")
                
               }
        
        
        
        if let storyboard = self.storyboard {
        let newViewController = storyboard.instantiateViewController(withIdentifier: "slidemenu")
            self.present(newViewController, animated: true, completion: nil)
            
            guard let navigationController = self.navigationController else { return }
            var navigationArray = navigationController.viewControllers // To get all UIViewController stack as Array
            navigationArray.remove(at: navigationArray.count) // To remove previous UIViewController
            self.navigationController?.viewControllers = navigationArray
            
    }
        

}
}
