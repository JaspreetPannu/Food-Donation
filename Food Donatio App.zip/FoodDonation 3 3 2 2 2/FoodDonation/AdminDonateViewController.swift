//
//  AdminDonateViewController.swift
//  FoodDonation
//
//  Created by Sidharth Mehta on 08/08/20.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import CoreData

class AdminDonateViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    typealias ImageArray = [UIImage]
   
    @IBOutlet weak var table: UITableView!
     var rslt :EntityDonate!
    var list1:[EntityDonate] = []
    var z : Date!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "id", for: indexPath) as! DonateCell
       
        let rslt = list1[indexPath.row]
        cell.amount.text = String(rslt.amount)
        cell.fname.text = rslt.name
        
        
        cell.img.animationImages = imageArray()
        cell.img.animationDuration = 3.0
        cell.img.startAnimating()
        
        
        let formatter = DateFormatter()
               // initially set the format based on your datepicker date / server String
               formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

        let myString = formatter.string(from: rslt.time!) // string purpose I add here
               // convert your string to date
               let yourDate = formatter.date(from: myString)
               //then again set the date format whhich type of output you need
               formatter.dateFormat = "dd-MMM-yyyy HH:mm:ss"
               // again convert your date to string
               let myStringafd = formatter.string(from: yourDate!)
                cell.date.text = myStringafd
        
        
        
        
        
        
        return cell
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
 
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fetch()
       // let donation = DatabaseHelper.instance.getAllDonation()
        table.reloadData()
    }
    func fetch() {
        let request = NSFetchRequest<EntityDonate>(entityName: "EntityDonate")
        
        do{
            
          list1 =  try context.fetch(request)
        }
            catch
            {
                print(error)
            }
            
        }
    
    
        // for delete
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete{
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            context.delete(self.list1[indexPath.row])
            do{
                try context.save()
                self.fetch()
                self.table.reloadData()
            }
            catch{}
        }
    }
   //
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "masterToDonate" {
            
            let destvc = segue.destination as! AdminDonateDetailViewController
            
            destvc.rslt = (sender as? [EntityDonate])!
            print("mai pc hu")
        }
    }
    
    
    
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("am here")
         rslt = list1[indexPath.row]
        performSegue(withIdentifier: "masterToDonate", sender: rslt)
        
    }
    
    
    
    
    
    func imageArray() -> ImageArray? {
        let getInfo = DatabaseHelper.instance.getAllDonation()
    if let mySavedData = NSKeyedUnarchiver.unarchiveObject(with: getInfo.7!) as? NSArray {
            // TODO: Use regular map and return nil if something can't be turned into a UIImage
        let imgArray = mySavedData.compactMap({
                return UIImage(data: $0 as! Data)
            })
            return imgArray
        }
        else {
            print("Unable to convert data to ImageArray")
            return nil
        }
    }
    
    
    
    
    
    }


